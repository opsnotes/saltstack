#!/bin/bash
mkdir -p /usr/local/nginx/{client,proxy,fcgi} && chown -R nginx.nginx /usr/local/nginx/

